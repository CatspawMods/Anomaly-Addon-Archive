**Required by** `utils_catspaw_hudmarks.script`
