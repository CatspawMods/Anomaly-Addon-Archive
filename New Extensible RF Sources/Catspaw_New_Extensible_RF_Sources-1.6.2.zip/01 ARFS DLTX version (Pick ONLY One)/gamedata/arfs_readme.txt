Anomalous RF Signals (included with New Extensible RF Sources)
Author: Catspaw
https://www.moddb.com/mods/stalker-anomaly/addons/anomalous-rf-signals-10

Adds diegetic lore notes which are dropped by stalkers, teaching the player which RF frequencies are useful.
